#!/bin/bash

make install_python_reqs

make clean_cmake

make vs_cmake

make vs_run_tests

