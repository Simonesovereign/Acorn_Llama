
.. mdinclude:: ../../examples/android/android-simple/README.md

