
.. mdinclude:: ../../examples/neural_network_vgg7/README.md

