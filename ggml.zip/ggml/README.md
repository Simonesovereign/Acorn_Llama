# GGML Kernels

This directory should contain the GGML source files and Metal kernels:

## Required Files:
- All .c and .cpp files from ggml/src/
- Metal kernel files (.metal)
- Any other GGML-related source files

## Metal Backend

Ensure Metal backend support is included for optimal macOS performance.
