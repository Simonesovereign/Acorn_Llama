# Acorn Integration Guide

## Quick Setup

### 1. Copy Your Working Build
```bash
# Copy your modified llama.cpp files
cp -r /path/to/your/working/llama.cpp/src/* ./src/
cp -r /path/to/your/working/llama.cpp/ggml/* ./ggml/
cp /path/to/your/working/llama.cpp/default.metallib ./
```

### 2. Test the Package
```bash
swift build
```

### 3. Deploy to GitHub
```bash
./deploy.sh
# Upload the zip to GitHub
```

### 4. Add to Xcode
1. File → Add Package Dependencies
2. Enter: `https://github.com/gabrieldeanroberts/llama.cpp-acorn`
3. Select main branch
4. Add to ACORN MAC OS target

## Expected Results

After integration, your Acorn app should show:
```
✅ LLaMA context initialized successfully
✅ Loaded architecture: qwen3
✅ Model loaded: ACORN_SMALL_Q6_K
```

## Troubleshooting

- **Build fails**: Check that all source files are copied correctly
- **Qwen3 not supported**: Verify your llama.cpp modifications are included
- **Metal errors**: Ensure default.metallib is in the root directory

## Version Management

Tag your releases:
```bash
git tag v1.0.0
git push origin v1.0.0
```

This ensures Acorn always uses the exact version that works with your Qwen3 model.
