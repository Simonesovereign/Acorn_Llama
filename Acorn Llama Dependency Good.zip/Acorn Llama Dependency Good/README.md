# Acorn Llama Package

This is a custom Swift Package containing a modified llama.cpp build with Qwen3 architecture support for the Acorn application.

## Features

- ✅ Full Qwen3 architecture support
- ✅ Metal backend optimization for macOS
- ✅ Accelerate framework integration
- ✅ Swift Package Manager compatibility

## Installation

Add this package to your Xcode project:

1. File → Add Package Dependencies
2. Enter the repository URL
3. Select the main branch
4. Add to your target

## Usage

```swift
import AcornLlama

// Your custom Qwen3 models will now load successfully
let context = try await LlamaContext.create_context(path: modelPath)
```

## Architecture Support

This package supports:
- `qwen` (Qwen1)
- `qwen2` 
- `qwen2moe`
- `qwen3` ← **Custom support for Acorn**

## Build Requirements

- macOS 13.0+
- Xcode 15.0+
- Metal-capable Mac

## License

Based on llama.cpp with custom Qwen3 modifications for Acorn.
