
.. mdinclude:: ../../examples/godot_logistic_regression/README.md

.. mdinclude:: ../../examples/godot_logistic_regression/custom_module/README.md

.. mdinclude:: ../../examples/godot_logistic_regression/gdnative_shared/README.md

