/* register_types.h */
#pragma once

void
register_kompute_model_ml_types();
void
unregister_kompute_model_ml_types();
/* yes, the word in the middle must be the same as the module folder name */
