#!/bin/bash

# Acorn Llama Package Setup Script
# This script helps you copy your working llama.cpp build into this package structure

echo "🧱 Setting up Acorn Llama Package..."

# Check if we're in the right directory
if [ ! -f "Package.swift" ]; then
    echo "❌ Error: Please run this script from the Acorn Llama Dependency Good directory"
    exit 1
fi

echo "📁 Package structure created:"
echo "├── Package.swift"
echo "├── include/"
echo "│   └── AcornLlama.h"
echo "├── src/ (copy your .cpp/.c files here)"
echo "├── ggml/ (copy your ggml files here)"
echo "└── default.metallib (copy from your build)"

echo ""
echo "📋 Next steps:"
echo "1. Copy your working llama.cpp source files to src/"
echo "2. Copy your ggml files to ggml/"
echo "3. Copy default.metallib to the root directory"
echo "4. Test the package with: swift build"
echo "5. Create a GitHub repository and push"
echo "6. Add the package to your Xcode project"

echo ""
echo "🔗 To add to Xcode:"
echo "File → Add Package Dependencies → Enter your GitHub URL"

echo ""
echo "✅ Setup complete! Ready for your llama.cpp files."
