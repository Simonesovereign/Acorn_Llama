#!/bin/bash

# Acorn Llama Package Deployment Script
# This script creates a zip file ready for GitHub or distribution

echo "🚀 Creating Acorn Llama Package for deployment..."

# Check if we're in the right directory
if [ ! -f "Package.swift" ]; then
    echo "❌ Error: Please run this script from the Acorn Llama Dependency Good directory"
    exit 1
fi

# Create zip file
echo "📦 Creating zip file..."
cd "/Volumes/OAK_CORE"
zip -r "AcornLlamaPackage.zip" "Acorn Llama Dependency Good" -x "*.DS_Store" "*/.*"

echo "✅ Package created: /Volumes/OAK_CORE/AcornLlamaPackage.zip"
echo ""
echo "📋 Next steps:"
echo "1. Upload AcornLlamaPackage.zip to GitHub"
echo "2. Or extract and push to a new repository"
echo "3. Add the GitHub URL to your Xcode project"
echo ""
echo "🔗 GitHub setup:"
echo "1. Create new repository: llama.cpp-acorn"
echo "2. Upload the zip contents"
echo "3. Use URL: https://github.com/gabrieldeanroberts/llama.cpp-acorn"
